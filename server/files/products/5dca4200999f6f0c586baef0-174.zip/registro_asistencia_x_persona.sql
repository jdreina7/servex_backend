/**
 *
 * @autor     		Juan David Reina
 * @access    		public
 * @package   		Registro Academico
 * @copyright 		DataSae, Parte de la Familia DataCorp
 * @since     		2018-10-02
 * @version   		1.0
 * @description		Creación de la tabla de registros de asistencia por persona para el control de asistencia de las personas
 *
 */
 
CREATE TABLE registro_asistencia_x_persona (
    rapp_codigo                	SERIAL  NOT NULL,
    rapp_per_codigo             INT4 NOT NULL DEFAULT 0 REFERENCES Persona ON UPDATE CASCADE,
	rapp_fecha_registro			TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    rapp_usu_login             	VARCHAR(20) NOT NULL DEFAULT 'ninguno' REFERENCES Usuario ON UPDATE CASCADE,
    rapp_fecha_modificacion    	TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    rapp_registro_vigente      	BOOLEAN     NOT NULL DEFAULT TRUE,
    PRIMARY KEY (rapp_codigo)
);

alter table tipo_registro_asistencia owner to administrador;
