/**
 *
 * @autor     		Juan David Reina
 * @access    		public
 * @package   		Registro Academico
 * @copyright 		DataSae, Parte de la Familia DataCorp
 * @since     		2018-10-02
 * @version   		1.0
 * @description		Creación de la tabla de tipos de registro de asistencia e inserción de los dos tipos default
 *
 */
 
CREATE TABLE tipo_registro_asistencia (
    tras_codigo                	SERIAL  NOT NULL,
    tras_nombre_registro        VARCHAR(20),
    tras_usu_login             VARCHAR(20) NOT NULL DEFAULT 'ninguno' REFERENCES Usuario ON UPDATE CASCADE,
    tras_fecha_modificacion    TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tras_registro_vigente      BOOLEAN     NOT NULL DEFAULT TRUE,
    PRIMARY KEY (tras_codigo)
);

alter table tipo_registro_asistencia owner to administrador;

INSERT INTO tipo_registro_asistencia (tras_nombre_registro)
VALUES ('Ingreso');

INSERT INTO tipo_registro_asistencia (tras_nombre_registro)
VALUES ('Salida');
